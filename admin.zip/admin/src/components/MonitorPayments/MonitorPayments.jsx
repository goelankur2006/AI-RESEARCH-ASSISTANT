import React from 'react'

const MonitorPayments = () => {
  return (
    <div>MonitorPayments</div>
  )
}

export default MonitorPayments