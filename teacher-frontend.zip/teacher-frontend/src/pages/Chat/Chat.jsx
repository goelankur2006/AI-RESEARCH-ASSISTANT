import React from 'react'

const Chat = () => {
  return (
    <div>Chat</div>
  )
}

export default Chat