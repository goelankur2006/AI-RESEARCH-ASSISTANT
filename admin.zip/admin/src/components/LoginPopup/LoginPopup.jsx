import React from 'react'

const LoginPopup = () => {
  return (
    <div>LoginPopup</div>
  )
}

export default LoginPopup