import logo from './logo.jpg';
import React from 'react'
import cross_icon from "./cross_icon.png";

export const assets={
  logo,
  cross_icon,
};

export default assets