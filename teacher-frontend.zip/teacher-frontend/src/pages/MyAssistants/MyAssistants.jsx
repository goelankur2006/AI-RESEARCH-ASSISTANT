import React from 'react'

const MyAssistants = () => {
  return (
    <div>MyAssistants</div>
  )
}

export default MyAssistants