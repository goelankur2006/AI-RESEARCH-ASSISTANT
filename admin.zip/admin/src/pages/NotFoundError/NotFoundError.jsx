import React from 'react'

const NotFoundError = () => {
  return (
    <div>NotFoundError</div>
  )
}

export default NotFoundError