import React from 'react'

const NewRequests = () => {
  return (
    <div>NewRequests</div>
  )
}

export default NewRequests