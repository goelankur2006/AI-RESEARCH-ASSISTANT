import React from 'react'

const MakePayment = () => {
  return (
    <div>
      <h2>Make Payment</h2>
      <p>Here you can make payments for your projects.</p>
    </div>
  )
}

export default MakePayment