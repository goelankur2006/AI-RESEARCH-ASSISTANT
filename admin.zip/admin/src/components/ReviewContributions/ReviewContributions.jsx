import React from 'react'

const ReviewContributions = () => {
  return (
    <div>ReviewContributions</div>
  )
}

export default ReviewContributions