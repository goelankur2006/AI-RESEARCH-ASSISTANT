import React from 'react'

const assets = () => {
  return (
    <div>assets</div>
  )
}

export default assets