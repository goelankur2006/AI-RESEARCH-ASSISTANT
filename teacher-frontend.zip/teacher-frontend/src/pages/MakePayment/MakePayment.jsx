import React from 'react'

const MakePayment = () => {
  return (
    <div>MakePayment</div>
  )
}

export default MakePayment